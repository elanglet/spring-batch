package fr.formation.introspringbatch;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntroSpringBatchApplication implements CommandLineRunner {

	// On injecte le Job et le JobLauncher
	@Autowired
	private Job job;
	
	@Autowired
	private JobLauncher jobLauncher;


	@Override
	public void run(String... args) throws Exception {
		// On définit des paramètres pour identifier chaque JobInstance
		Map<String, JobParameter> params = new HashMap<String, JobParameter>();
		
		params.put("date.du.job", new JobParameter(new Date()));
		params.put("action.du.job", new JobParameter("bye"));
		
		// On lance le Job avec ses paramètres
		jobLauncher.run(job, new JobParameters(params));
	}
	
	public static void main(String[] args) {
		SpringApplication.run(IntroSpringBatchApplication.class, args);
	}	

}
