package fr.formation.introspringbatch.steps;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class OtherTasklet implements Tasklet {

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		System.out.println(" *** Execution de 'OtherTasklet' ... *** ");
		
		// Définir un etat de sortie pour cette étape 
		contribution.setExitStatus(ExitStatus.COMPLETED);
		
		// Etat de reprise de cette étape		
		return RepeatStatus.FINISHED;
	}

}
